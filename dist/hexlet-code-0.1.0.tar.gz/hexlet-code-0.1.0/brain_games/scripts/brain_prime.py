#!/urs/bin/evn python

"""Scripts for starting game_prime"""


from brain_games.games.game_prime import game_prime


def main():
    game_prime()


if __name__ == '__main__':
    main()
