#!/urs/bin/evn python

"""Scripts for starting game_gdc"""


from brain_games.games.game_gcd import game_gcd


def main():
    game_gcd()


if __name__ == '__main__':
    main()
