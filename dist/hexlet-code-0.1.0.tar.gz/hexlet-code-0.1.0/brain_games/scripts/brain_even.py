#!/urs/bin/evn python

"""Scripts for starting game_even"""


from brain_games.games.game_even import game_even


def main():
    game_even()


if __name__ == '__main__':
    main()
