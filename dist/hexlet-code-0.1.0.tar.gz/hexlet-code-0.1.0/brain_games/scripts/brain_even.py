#!/urs/bin/evn python

"""Scripts for starting game_1"""


from brain_games.game_1 import game_1


def main():
    game_1()


if __name__ == '__main__':
    main()
