#!/urs/bin/evn python

"""Scripts for starting game_calc"""


from brain_games.games.game_calc import game_calc


def main():
    game_calc()


if __name__ == '__main__':
    main()
