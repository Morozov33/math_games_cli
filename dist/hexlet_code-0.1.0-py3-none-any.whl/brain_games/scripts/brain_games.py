#!/urs/bin/evn python

"""Scripts for starting greeting"""


from brain_games.greeting import welcome_user


def main():
    welcome_user()


if __name__ == '__main__':
    main()
