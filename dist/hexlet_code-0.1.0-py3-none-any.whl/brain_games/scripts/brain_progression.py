#!/urs/bin/evn python

"""Scripts for starting game_progression"""


from brain_games.games.game_progression import game_progression


def main():
    game_progression()


if __name__ == '__main__':
    main()
